const puppeteer = require('puppeteer');

// Configurare cuvinte cheie
const searchKeywords = [
    '21collagen',
    'collagen 21',
    'colagen 21',
    // Adăugați mai multe cuvinte cheie aici
];

// Funcție pentru a genera un delay aleatoriu între căutări (între 1-2 ore)
function getRandomDelay() {
    return Math.floor(Math.random() * (7200000 - 3600000) + 3600000); // între 1-2 ore în millisecunde
}

// Funcție pentru a alege random un cuvânt cheie
function getRandomKeyword() {
    return searchKeywords[Math.floor(Math.random() * searchKeywords.length)];
}

// Funcție pentru a determina numărul de căutări pe zi
function getSearchesPerDay() {
    const startDate = new Date('2024-03-14'); // Data de început - actualizați cu data dvs
    const today = new Date();
    const diffTime = Math.abs(today - startDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays <= 14 ? 6 : 15; // primele 2 săptămâni 6 căutări, apoi 15
}

async function performSearch(page, keyword) {
    try {
        // Accesăm site-ul
        await page.goto('https://makeup.com');
        
        // Așteptăm 1 minut după încărcarea paginii
        console.log('Așteptăm 1 minut înainte de căutare...');
        await new Promise(resolve => setTimeout(resolve, 60000));
        
        // Click pe butonul de căutare
        await page.waitForSelector('.circle');
        await page.click('.circle');
        console.log('Am deschis câmpul de căutare');
        
        // Așteptăm să apară câmpul de căutare și introducem cuvântul cheie
        await page.waitForSelector('#search-field');
        await page.type('#search-field', keyword, {delay: 100});
        console.log(`Am introdus cuvântul cheie: ${keyword}`);
        
        // Apăsăm Enter pentru căutare
        await page.keyboard.press('Enter');
        await page.waitForNavigation({ waitUntil: 'networkidle0' });
        
        // Simulăm scroll pentru a părea mai natural
        await page.evaluate(() => {
            window.scrollBy(0, Math.random() * 500);
        });
        
        // Așteptăm 30 secunde înainte de următoarea căutare
        console.log('Așteptăm 30 secunde înainte de următoarea acțiune...');
        await new Promise(resolve => setTimeout(resolve, 30000));
        
    } catch (error) {
        console.error(`Eroare la căutare: ${error.message}`);
    }
}

async function main() {
    const browser = await puppeteer.launch({
        headless: false,
        args: [
            '--no-sandbox',
            '--disable-setuid-sandbox'
        ]
    });

    try {
        const page = await browser.newPage();
        await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36');
        
        while (true) {
            const searchesToday = getSearchesPerDay();
            console.log(`Efectuăm ${searchesToday} căutări astăzi`);
            
            for (let i = 0; i < searchesToday; i++) {
                const keyword = getRandomKeyword();
                console.log(`\nÎncepem căutarea ${i + 1}/${searchesToday}: "${keyword}"`);
                
                await performSearch(page, keyword);
                
                if (i < searchesToday - 1) {
                    const delay = getRandomDelay();
                    console.log(`Pauză de ${Math.floor(delay/1000/60)} minute până la următoarea căutare`);
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
            
            console.log('\nPauză de noapte (8 ore)...');
            await new Promise(resolve => setTimeout(resolve, 8 * 3600000));
        }
    } catch (error) {
        console.error(`Eroare generală: ${error.message}`);
        await browser.close();
    }
}

main().catch(console.error); 